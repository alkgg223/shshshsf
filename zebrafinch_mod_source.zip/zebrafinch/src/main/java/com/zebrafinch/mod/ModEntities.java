package com.zebrafinch.mod;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ZebraFinchMod.MODID);

    // Half of the vanilla parrot hitbox (0.25 x 0.45)
    public static final DeferredHolder<EntityType<?>, EntityType<ZebraFinch>> ZEBRA_FINCH =
            ENTITIES.register("zebra_finch", () -> EntityType.Builder.of(ZebraFinch::new, MobCategory.CREATURE)
                    .sized(0.25F, 0.45F)
                    .clientTrackingRange(8)
                    .build("zebra_finch"));
}
