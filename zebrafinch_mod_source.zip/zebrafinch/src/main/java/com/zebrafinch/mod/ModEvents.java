package com.zebrafinch.mod;

import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

public class ModEvents {

    @EventBusSubscriber(modid = ZebraFinchMod.MODID, bus = EventBusSubscriber.Bus.MOD)
    public static class Common {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent event) {
            event.put(ModEntities.ZEBRA_FINCH.get(), ZebraFinch.createAttributes().build());
        }

        @SubscribeEvent
        public static void spawns(RegisterSpawnPlacementsEvent event) {
            event.register(ModEntities.ZEBRA_FINCH.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ZebraFinch::checkSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.OR);
        }
    }

    @EventBusSubscriber(modid = ZebraFinchMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Client {
        @SubscribeEvent
        public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
            event.registerLayerDefinition(ZebraFinchModel.LAYER, ZebraFinchModel::createBodyLayer);
        }

        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ModEntities.ZEBRA_FINCH.get(), ZebraFinchRenderer::new);
        }
    }
}
