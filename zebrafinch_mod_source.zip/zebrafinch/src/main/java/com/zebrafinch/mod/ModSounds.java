package com.zebrafinch.mod;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, ZebraFinchMod.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> MEEP = SOUNDS.register("entity.zebra_finch.meep",
            () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath(ZebraFinchMod.MODID, "entity.zebra_finch.meep")));
}
